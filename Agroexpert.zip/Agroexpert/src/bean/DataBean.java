package bean;

public class DataBean 
{
	public String marketName;
	public float result;
	
	public DataBean(String marketName,float result)
	{
		this.marketName=marketName;
		this.result=result;
	}

}